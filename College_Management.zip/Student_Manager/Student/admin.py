from django.contrib import admin
from Student.models import Student_Register

class StudentAdmin(admin.ModelAdmin):
    list_display=['name','std_id','stream','mobile']

admin.site.register(Student_Register,StudentAdmin)

# Register your models here.
